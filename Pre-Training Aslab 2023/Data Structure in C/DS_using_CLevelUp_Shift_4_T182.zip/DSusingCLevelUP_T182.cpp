#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Option 1 add queue, tambahin job lalu pushHead job itu jadi data pertama
//kalo delete queue pake poptail
//Konsep data fifo = first in first out, artinya ketika data pertama dimasukkan dengan popHead, lama-lama ia akan menjadi data terakhir alias tail, untuk menghilangkan si data pertama, maka pakai popTail
struct data{
	char id[11];
	char job[3];
	char assistant[7];
	char time[101];
	int priority;
}*head = NULL, *tail = NULL;
	
struct node{
	int value;
	node* next;
	node* prev;
};

data *newNote{
}

void pushHead{
	if(head==NULL){
	head=tail=NULL
	}else{
		
	}
}

void popTail{
	if(head==NULL){
	head=tail=NULL;
	}else{
		
	}
}

int main(){
	int choice;
	puts("acadeMLic");
	printf("\n");	
	FILE *data = fopen("database.dat", "r");
	printf("\n");	
	printf("\n");	
	puts("1. Add queue");
	puts("2. Pop queue");
	puts("3. Exit");
	printf("> ");
	scanf("%d", &choice);
	if(choice == 1){
		system("cls");
		char choice1;
		do{
			printf("Job name [Must be 'Casemaking' Or 'Correction', or 'VBL'] : ");
			scanf("%s",&job);
		}while(job!= "Casemaking" || job!= "Correction" || job!= "VBL");
		do{
		puts("Assistant to be assigned [XXYY-Z]: ");
		scanf("%s",&assitant);
		}while(assistant!= );
		system("cls");
		puts("Job name : %s", &job);
		puts("Assistant to be assigned : %s",&assistant);
		printf("Are you sure ? [Y/N] : ");
		scanf("%c", &choice1);
		if(choice1 == Y){
			printf("Successfully created new queue...\n");
			printf("Press enter to continue...");
			scanf("\n");getchar();
		}else if(choice1 == N){
			puts("Process canceled...");
			puts("Press enter to continue...");
			scanf("\n");getchar();	
		}	
	} else if(choice == 2){
		system("cls");
		scanf("%c", &choice1);
		if(choice1 == Y){
			printf("Successfully popped the queue !\n");
			printf("Press enter to continue...");
			scanf("\n");getchar();
		}else if(choice1 == N){
			printf("Process canceled...");
			scanf("\n");getchar();	
		}
	}
	else if(choice == 3){
		system("cls");
	}
	return 0;
}
