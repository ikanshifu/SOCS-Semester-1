package main;

public class Salon {
	private String salonName;
	public Salon(String salonName){
		super();
		this.salonName = salonName;	
	}
	public String getSalonName() {
		return salonName;
	}
	public void setSalonName(String salonName) {
		this.salonName = salonName;
	}

}
