package main;
import java.util.Scanner;
import view.MainMenu;
import view.Register;
import view.Login;
public class Main {
	Scanner scan = new Scanner(System.in);
	
	public Main() {
		MainMenu menu = new MainMenu();
		Login submenu1 = new Login();
		Register submenu2 = new Register();
		Integer inputChoice = 0;
		do {
			menu.printMainMenu();
			inputChoice = scan.nextInt();
			switch(inputChoice) {
			case 1:
				submenu1.printLogin();
				break;
			case 2:
				submenu2.printRegister();
				break;
			case 3:
				System.out.println("Farewell Dokutah...");
				System.out.println("Press [ENTER] to continue...");
				break;
			}
		}while (inputChoice	> 0 && inputChoice < 4);
	}
	public static void main(String[] args) {
		new Main();
	}

}
