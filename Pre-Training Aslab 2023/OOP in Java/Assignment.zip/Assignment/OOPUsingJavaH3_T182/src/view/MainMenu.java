package view;

public class MainMenu {
	public MainMenu(){
		

}

public void printMainMenu(){
	System.out.println("____ ____ _  _ _  _ _ ____ _  _ ___ ____\r\n" + 
			"|__| |__/ |_/  |\\ | | | __ |__|  |  |  |\r\n" + 
			"|  | |  \\ | \\_ | \\| | |__] |  |  |  |__|");
	System.out.println();
	System.out.println("1. Login");
	System.out.println("2. Register");
	System.out.println("3. Exit");
	System.out.print(">> ");
}
}
