import java.util.Scanner;

public class Main {

	public Main() {
		Scanner scanner = new Scanner(System.in);
		int choice;
		System.out.println("1. Add Ticket");
		System.out.println("2. View List Order");
		System.out.println("3. Manage Order");
		System.out.println("4. Sorting");
		System.out.println("0. Exit");
		System.out.print(">>");
		choice = scanner.nextInt();
	}

	public static void main(String[] args) {


	}

}
