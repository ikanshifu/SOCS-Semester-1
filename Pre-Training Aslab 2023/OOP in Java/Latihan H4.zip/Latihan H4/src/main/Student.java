package main;

public class Student {
	private String name;
	private Integer age;
	private String NIM;
	public Student(String name, Integer age, String NIM) {
		super();
		this.name = name;
		this.age = age;
		this.NIM = NIM;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getNIM() {
		return NIM;
	}
	public void setNIM(String NIM) {
		this.NIM = NIM;
	}
	
}
