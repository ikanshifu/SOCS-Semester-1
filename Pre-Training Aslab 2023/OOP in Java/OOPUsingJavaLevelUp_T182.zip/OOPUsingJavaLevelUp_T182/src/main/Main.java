package main;
import java.util.Scanner;
public class Main {
	Scanner scan = new Scanner(System.in);
	
	public void inputVehicle(String name, String type, int year, int seats, int power) {
		try {
			System.out.println("Owner Name [5-25 characters]: ");
			name = scan.nextLine();
		} catch (Exception e) {
			System.out.println("Name length must between 5 and 25 characters");
		}
		try {
			System.out.println("Vehicle Type [Car | Motorcycle] (Case sensitive):");
			type = scan.nextLine();
		} catch (Exception e) {
			System.out.println("Vehicle Type [Car | Motorcycle] (Case sensitive):");
		}
		try {
			System.out.println("Vehicle Year [2000-2020]: ");
			year = scan.nextInt();
		} catch (Exception e) {
			System.out.println("Only accept vehicle year 2000 - 2020");
		}
		if(type == "Car") {
			try {
				System.out.println("Input Car Seat [min. 1]: ");
				seats = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Minimal input 1 seat");
			}
		}else{
			try {
				System.out.println("Input Motorcycle Cc [min. 200]: ");
				power = scan.nextInt();
			} catch (Exception e) {
				System.out.println("Minimal input 200 Cc");
		}
		System.out.println("Success insert broken vehicle");
		}
	}
	
	public void viewVehicle() {
		System.out.println("=========================\r\n"
				+ "|       View Vehicle    |\r\n"
				+ "=========================");scan.nextLine();
	}
	
	public void repairCar() {
		
	}
	
	public void repairMotorcycle() {
		
	}
	
	public void repairAll() {
		
	}
	
	public void exitMenu() {
		System.out.println(" Thank you for using this program.\r\n"
				+ "                                  .......,*...\r\n"
				+ "                           ......&..........,%&&&*&.......\r\n"
				+ "                         ...%.,.../(..&/,     .....,..(..,*....\r\n"
				+ "                      ..#,......#*,..............   ..../%.....\r\n"
				+ "                   .,/(.....(, .*....................  ...*\r\n"
				+ "                  .,#,...,,. .........................  ,...% .\r\n"
				+ "              ...&/((&#*,...............*&@@%...........  ,*,,....\r\n"
				+ "             ..(,*.... ./,.%,...... /&@@@@@ .............  .*,/...\r\n"
				+ "              ......./ .....*** &@@@@@&#.................. ..(,&\r\n"
				+ "                 (,.,....,..(@@@@@@/./@@@@@@@@@#*.......,*...,*.(\r\n"
				+ "                 %,,,..,,,.,.@@@@@@@#&......,@@@@@@@@@%.... .,/,%\r\n"
				+ "               ..%,,. ..,..,,,,../@@@@@@@@.../@@@@@#...... ..*,*(,\r\n"
				+ "               ..#... ..,,..,..........,,.(@@@@@ ......... ..../.,.\r\n"
				+ "                ./.... .. ......... .,&@@@@@%............. .*.,% /.\r\n"
				+ "                .  ...,#........... *@@@(.....,...........,(..#..,..\r\n"
				+ "                    .*. ,................,......,.......,&,,..\r\n"
				+ "                     *.,.(...*......,.......,..,.. .  .&,..\r\n"
				+ "                       ..,,,* . .*..,......    ...,%(...(,..\r\n"
				+ "                       .,**#,*#,..(.#...,,,#&%###...*,*,...\r\n"
				+ "                       . ...&&/.*&,.*&.......(#.\r\n"
				+ "                            ..   ..*...,,..\r\n"
				+ "                                  .......\r\n"
				+ "\r\n"
				+ "                                - Bluejackets 22-1 -\r\n"
				+ "        Alongside courage and perseverance, we shape and define our future.");
	}
	
	public void mainMenu() {
		int choice = 0;
		do{
			System.out.println("=========================\r\n"
					+ "|       GWaraGe 101     |\r\n"
					+ "=========================");
			System.out.println("1. Input Vehicle");
			System.out.println("2. View Vehicle");
			System.out.println("3. Repair Car");
			System.out.println("4. Repair Motorcycle");
			System.out.println("5. Repair All");
			System.out.println("6. Exit");
			System.out.print("> ");
			choice = scan.nextInt();
				switch (choice) {
				case 1:
					inputVehicle(null, null, choice, choice, choice);
					System.out.println("Press enter to continue");scan.nextLine();
					mainMenu();
					break;
				case 2:
					viewVehicle();
					System.out.println("Press enter to continue");scan.nextLine();
					mainMenu();
					break;
				case 3:
					repairCar();
					System.out.println("Press enter to continue");scan.nextLine();
					mainMenu();
					break;
				case 4:
					repairMotorcycle();
					System.out.println("Press enter to continue");scan.nextLine();
					mainMenu();
					break;
				case 5:
					repairAll();
					System.out.println("Press enter to continue");scan.nextLine();
					mainMenu();
					break;
				case 6:
					exitMenu();
					System.exit(0);
					break;
				}
		}while(choice >= 1 && choice <= 6||choice<1||choice>6);
	}
	
	public Main() {
		mainMenu();
	}

	public static void main(String[] args) {
	new Main();

	}

}
