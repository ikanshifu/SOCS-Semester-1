package main;

public class Motorcycle extends Owner {

	private int power;

	public Motorcycle(String name, String type, int year, int power) {
		super(name, type, year, power);
		this.power = power;	
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}
}
