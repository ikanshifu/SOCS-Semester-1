package main;

public class Master {

}
