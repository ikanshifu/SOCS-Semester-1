package main;

public class Owner {
		public String name;
		public String type;
		public int year;

		
		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getType() {
			return type;
		}


		public void setType(String type) {
			this.type = type;
		}


		public int getYear() {
			return year;
		}


		public void setYear(int year) {
			this.year = year;
		}


		public Owner(String name,String type,int year, int seats) {
			super();
			this.name = name;
			this.type = type;
			this.year = year;
		}
}
