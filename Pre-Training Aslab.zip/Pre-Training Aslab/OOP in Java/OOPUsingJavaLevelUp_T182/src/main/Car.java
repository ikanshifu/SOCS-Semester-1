package main;

public class Car extends Owner{
		private int seats;
		
	public Car(String name, String type, int year, int seats) {
		super(name, type, year, seats);
		this.seats = seats;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}
}
