For windows users, just double click(to run) the .exe file.


For macos users, run the run-macos.sh file. 
> To run the .sh file, open a terminal window in the folder which contains the supplied .jar file, then execute './run-macos.sh'. 
> If you're getting a "permission denied" message whilst running the .sh file, ensure that the .sh file is executable by executing 'chmod +x run-macos.sh'.


For linux users, run the run-ubuntu.sh file. 
> To run the .sh file, open a terminal window in the folder which contains the supplied .jar file, then execute './run-ubuntu.sh'. 
> This file is optimized for ubuntu users using the gnome-terminal, if your linux distro uses a different terminal, please change the .sh file accordingly, or manually run the .jar file. I'm sure that you're tech savvy enough to understand how to do this, right?
> If you're getting a "permission denied" message whilst running the .sh file, ensure that the .sh file is executable by running 'chmod +x run-ubuntu.sh'.


You may also run the jar file manually by typing "java -jar <jarFileName>.jar" on your command prompt or terminal. Ensure that your command prompt or terminal is on the same direcetory of the .jar file.


If you encounter any other problems, don't hesitate to ask your trainers or recsel officers. 
Good luck and have fun ;)