package view;
import java.util.Scanner;
public class Login {
	public Login() {

}
	public void printLogin() {
		Scanner scan = new Scanner(System.in);
		String name;
		String password;
		System.out.println("Please tell us your name, Dokutah... ['0' to go back]");
		System.out.print(">> ");
		name = scan.nextLine();
		System.out.println("Now, create a strong password to protect your identity, Dokutah... ['0' to go back]");
		System.out.print(">> ");
		password = scan.nextLine();
		scan.nextLine();
	}	
}
	

