package main;
import java.io.BufferedReader; 
import java.io.FileInputStream; 
import java.io.IOException; 
import java.io.InputStreamReader; 
import java.util.Scanner;

public class Score {
	public static void main(String args[]) throws IOException {
	final String highscore = "D:\\OOPUsingJavaH6_T182.txt";
	Scanner scan = new Scanner(new FileInputStream(highscore));
	BufferedReader buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(highscore)));
	
	while(scan.hasNextLine()) {
		System.out.println(scan.nextLine());
	}
	scan.close();
	
	String line = buffReader.readLine();
	while(line != null) {
		System.out.println(line);
		line = buffReader.readLine();
		}
	}
}
