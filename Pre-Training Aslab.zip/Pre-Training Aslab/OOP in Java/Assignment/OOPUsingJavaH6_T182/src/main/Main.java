package main;
import java.util.Scanner;
import main.Score;

public class Main {
	Scanner scan = new Scanner(System.in);
	
	public void mainMenu(){
		int choice = 0;
		do{
		System.out.println("  ____  _             _   _               __  __\r\n" + 
				" / ___|| |_ __ _ _ __| |_(_)_ __   __ _  |  \\/  | ___ _ __  _   _\r\n" + 
				" \\___ \\| __/ _` | '__| __| | '_ \\ / _` | | |\\/| |/ _ \\ '_ \\| | | |\r\n" + 
				"  ___) | || (_| | |  | |_| | | | | (_| | | |  | |  __/ | | | |_| |\r\n" + 
				" |____/ \\__\\__,_|_|   \\__|_|_| |_|\\__, | |_|  |_|\\___|_| |_|\\__,_|\r\n" + 
				"                                  |___/");
		System.out.println();
		System.out.println("1. Play New Hairsalon");
		System.out.println("2. High Score");
		System.out.println("3. Exit");
		System.out.println("Input [1..3]:");
		choice = scan.nextInt();scan.nextLine();
		switch (choice) {
		case 1:
			PlayMenu();
			break;
		case 2:
			HighScoreMenu();
			break;
		case 3:
			exitMenu();
			System.exit(0);
			break;		
			}
		}while (choice >= 1 && choice<=3 || choice <1 || choice>3);
	}
	
	public void exitMenu() {
		System.out.println(" .:^:.. ..^^:..\r\n" + 
				"                          ...   ...:.     .......    .\r\n" + 
				"                            .   . ^.   :..:~~77~~~::..::.. ..\r\n" + 
				"                          ::::..~..:..:~7~.: :^ ~^:~..:....:^~^:^~^\r\n" + 
				"                        ..      .. .^!777^~~!?~^~7:^::.  .5BGB##&#7.\r\n" + 
				"                             .:~!!. .:~^.77?P57P7!^::~::?5B&&#GGG5.\r\n" + 
				"                          .:^~~^^: YJJGBGP5YY7J7!^^^?7YG##P7^7#&B~:\r\n" + 
				"                        .^~~:  ~J55PJ~:.       ..~JPBBBY^. .:.JG!:!!^..\r\n" + 
				"                     ..^7~  .::???.         .~!JG&&#J:       .7!:.^77?!^..\r\n" + 
				"                   .:~7!:. ^Y^.  ..      .!JPB&&#Y:          .  :7!: ~G5?!:.\r\n" + 
				"                 .:~7?7..~!!       .:..^?YP&&&G7         .        ~J: .BP7J!:.\r\n" + 
				"               .:^777~^::7^          :JB&&#BG^ .                   .J! !YYYJ?^.\r\n" + 
				"              .:!JJJJ: :7G.         ?#&&&&B~                         ?5..^!~~!!:.\r\n" + 
				"             .:!YYY5~ .J&Y      . .5BBBBBG^                           YP  :?J!~!^.\r\n" + 
				"             .:!J?YJ^..P&!        P&&&&&#!             ..              #7 .^55?^~:\r\n" + 
				"              .^7!??^..P#? .  .   ~#&&&&&J:..   ...  .   ..  ...     . 5#..:J57~!:.\r\n" + 
				"              .:!J~~^.?G#5      .:.^JGBBBP5Y!^75GBGP5PJYPGPP5YYJ?!^    !&:.:??~?~:.\r\n" + 
				"               .^?5^:.JPBP!       .:::.. .!YYY&&&###&&&&YG##&&&&#B5:   !&:.^~!5J~.\r\n" + 
				"                .^??:.^^?77..                 ^:.  ..P&G:^&&&&&&&&7    PG ~7:JP7:.\r\n" + 
				"                .:^7? .~~J?7!                 .      7#^ P&&&&&&G^    :&^ 7?5?!:.\r\n" + 
				"                  .^J5.:!JPBBY            .:.       ^5^ 7###&#P^      G7..7G5!:.\r\n" + 
				"                   .^?5~^~:~PBP~.?!~: ^^7~^!^     .7: ~#&&#5~        ~~:.:PY~:.\r\n" + 
				"                    .^!5J7..~!B&PJY?J^J?YGY?7!:..^^:?#@&G7.        .~.::^Y!^.\r\n" + 
				"                     .:^??J!77JY57 .: :?#BYGG!7~:7G&#5~.           .~^!J5!:.\r\n" + 
				"                       .:~?JY~..... :.^!J^^!7~7PGPJ~.          ... ^?Y57:.\r\n" + 
				"                          :~75P~:.  ^^!!^~!JYJ57:..^^....:^!:  ...5GP7^.\r\n" + 
				"                          ::.:~^7.JY^?77Y5Y7^..::~??5J???5J: :?Y!J5!:.\r\n" + 
				"                           .  .^.7G&###B5!^:.:.::......~?J?YB#BY7^:.\r\n" + 
				"                              .^^YJ5###BG5J7!7JYPPGYJ??YPPPY?7~:.\r\n" + 
				"                              ..:^~^^........^~!~!!!!~^^::...\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"                        o---------------------------------------------o\r\n" + 
				"                        |      Breaking and Overcoming Challenges     |\r\n" + 
				"                        |    Through Courage Hardwork and Persistence |\r\n" + 
				"                        |           ~~ Bluejackets 23-1 ~~            |\r\n" + 
				"                        o---------------------------------------------o");
	}
	
	public void PlayMenu() {
		String salonName;
		try {
			System.out.println("Input you hairsalon's name [5..20 characters]:");
			salonName = scan.nextLine();
		} catch (Exception e) {
			System.out.println("name must be up to 5 characters");
		}	
		GameMenu();
	}
	
	public void GameMenu(){
		
	}
	
	public void HighScoreMenu() {
		int choice = 0;
		System.out.println("  _   _ _       _\r\n" + 
				" | | | (_) __ _| |__  ___  ___ ___  _ __ ___\r\n" + 
				" | |_| | |/ _` | '_ \\/ __|/ __/ _ \\| '__/ _ \\\r\n" + 
				" |  _  | | (_| | | | \\__ | (_| (_) | | |  __/\r\n" + 
				" |_| |_|_|\\__, |_| |_|___/\\___\\___/|_|  \\___|\r\n" + 
				"          |___/");
		System.out.println();
		Score.main(args);
		do {
		System.out.println("Enter 1 to back");
		choice = scan.nextInt();scan.nextLine();
		mainMenu();
		}while(choice !=2);
	}
	
	public Main() {
		mainMenu();
	}

	public static void main(String[] args) {
		new Main();
	}

}
