package main;

public class PartyMember {
	private String membername;
	
	public PartyMember(String membername) {
		super();
		this.membername = membername;
	}

	public String getMembername() {
		return membername;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}
	
	
}
