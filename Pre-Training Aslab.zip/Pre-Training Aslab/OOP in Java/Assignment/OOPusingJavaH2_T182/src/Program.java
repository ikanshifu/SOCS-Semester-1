//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.PrintWriter;
//import java.nio.Buffer;
import java.util.Scanner;


public class Program {
	
	public Program(){
		int choice;
		Scanner scanner = new Scanner(System.in);	
		System.out.println(" _ _ _ __        _           _     _   _      _____         _         _\r\n" + 
				"| | | |  |   ___| |_ _ _ ___|_|___| |_| |_   |   | |___ _ _|_|___ ___| |_ ___ ___\r\n" + 
				"| | | |  |__| .'| . | | |  _| |   |  _|   |  | | | | .'| | | | . | .'|  _| . |  _|\r\n" + 
				"|_____|_____|__,|___|_  |_| |_|_|_|_| |_|_|  |_|___|__,|\\_/|_|_  |__,|_| |___|_|\r\n" + 
				"                    |___|                                    |___|");
		System.out.println("1. Edit maze");
		System.out.println("2. Trace maze");
		System.out.println("3. Exit");
		System.out.print("Input [1-3]: ");
		choice = scanner.nextInt();
		if(choice == 1) {
			menu1();
			if(Choice1 == 1) {
				
			}if(Choice1 == 2) {
				
			}if(Choice1 == 3) {
				
			}if(Choice1 == 4) {
				
			}
			
		}else if(choice == 2) {
			menu2();
		}else if(choice == 3) {
			
			}
		
	}
	public void menu1() {
		int choice1;
		System.out.println("Edit maze");
		System.out.println("---------------------");
		System.out.println("1. View Maze");
		System.out.println("2. Create New Maze");
		System.out.println("3. Edit Current Maze");
		System.out.println("4. Save And Exit");
		System.out.print("Input [1-4]: ");
		choice1 = scanner.nextInt();
	}
	
	public void menu2() {

	}
	
	public static void main(String[] args) {

		new Program();
		}
		
	}

