package main;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class main {
	ArrayList<Student> dataStudent = new ArrayList<>();
	Scanner scan = new Scanner(System.in);
	public void createStudentMenu() {//berisi atribut yang dimiliki student
		String name;
		Integer age;
		String NIM;
		
		System.out.println("Nama: ");
		name = scan.nextLine();
		System.out.println("Umur: ");
		age = scan.nextInt();scan.nextLine();//seperti getchar() dalam C, untuk mengambil enter;
		System.out.println("NIM: ");
		NIM = scan.nextLine();
		
		dataStudent.add(new Student(name,age,NIM));
	}
	
	public void printStudent() {
		for(Student ms : dataStudent){
			System.out.println(ms.getName()+ "-" + ms.getAge() + "-" + ms.getNIM());		
		}
		scan.nextLine();
		System.out.println("Press enter to continue...");
		}
	public void mainMenu() {
		int choice = 0;
		do{
			System.out.println("1. Create Mahasiswa");
			System.out.println("2. Print All");
			System.out.println("3. Exit");	
			System.out.print(">> ");
			choice = scan.nextInt();scan.nextLine();
			
			switch(choice) {
			case 1:
				createStudentMenu();
				break;
			case 2:
				printStudent();
				break;
			case 3:
				System.exit(0);
			}
		}while(choice <=3 && choice >= 1 || choice < 1 || choice > 3);
	}
	public main() {
		mainMenu();
	}

	public static void main(String[] args) {
	new main();
	}

}
