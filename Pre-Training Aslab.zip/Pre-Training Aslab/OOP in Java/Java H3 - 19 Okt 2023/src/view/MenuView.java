package view;

public class MenuView {

	public MenuView() {
		// TODO Auto-generated constructor stub
	}

	public void printMainMenu() {
		System.out.println("1. View all students");
		System.out.println("2. Insert new students");
		System.out.println("3. Remove students");
		System.out.println("Input choice [1-3] : ");
		
	}

}
